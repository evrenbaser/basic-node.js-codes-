// dosya oluşturma ve yazdırma işlemi 
const fs = require('fs');
fs.appendFile('demo2.txt','merhaba evren',(error)=>{
    if (error)
         throw error;

         console.log("dosya ya ekleme yapıldı.");
});