exports.mydatetime=function(){
    return Date();
};