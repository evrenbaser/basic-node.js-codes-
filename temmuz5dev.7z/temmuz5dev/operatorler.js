/*   karşılaştırma operatörleri
==   eşit ise
===  veri türü dahil eşit ise
!=   eşit değilse
!==  veri türü dahil eşit değilse
>    büyüktür
<    küçüktür
>=   büyük eşittir
<=   küçük eşittir
*/
console.log(3==3);

// mantıksal operatörler
// ve &&
// ve ya ||  kullanımı
console.log(1==1 && 5==5 &&1<10);

console.log(1==5 && 5==5 && 1<10);

var sayi1=5;
var sayi2=10;
var sayi3=15;

var durum=(sayi1==5)&&(sayi2==2)&&(sayi3==3);
console.log(durum+" (sayi1==5)&&(sayi2==2)&&(sayi3==3)");

var durum2=(sayi1==5)||(sayi2==2)||(sayi3==6);
console.log(durum2+ " (sayi1==5)||(sayi2==2)||(sayi3==6)");

var yilankorktunmu = true;
var orumcekkorktunmu = true;
var Whooahhkorktunmu =true;

    if(yilankorktunmu)
    {
        console.log("yılanlar yılanlardır");
    }
    else if (orumcekkorktunmu)
    {
        console.log("örümcekler örümceklerdir");
    }
    else if(Whooahhkorktunmu)
    {
        console.log("korkmadın mı ? :)");
    }
    if(yilankorktunmu)
    {
        console.log("yılanlar yılanlardır");
    }
    if (orumcekkorktunmu)
    {
        console.log("örümcekler örümceklerdir");
    }
     if(Whooahhkorktunmu)
    {
        console.log("korkmadın mı ? :)");
    }

    var secim=10;

    if(secim==10)
    {
        console.log("seciminiz gerçekleşti");
    }
    if(secim!=10)
    {
        console.log("seciminiz gerçekleşmedi");
    }

    // fonksiyonlar çok önemli acayip müthiş önemli 
    function selamlasmaseronomisi()
    {
        console.log("merhaba nasılsın");
        console.log("iyidir senden ? ");
        console.log("teşekkür ederim bende gayet iyiydim seni görene kadar");
    }