// diskten dosya okuma işlemi 
const fs = require('fs');
fs.readFile('demofile.txt',(error,data)=>{
    if(error)
     console.log(error);
     console.log(data.toString());
     console.log("dosya okuma işlemi bitti");
});
const demoDosyasi = fs.readFileSync('demofile.txt');
console.log(demoDosyasi.toString());// console ekranına dosyayı yazma
console.log("dosya okuma işlemi bitti");