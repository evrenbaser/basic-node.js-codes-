var http = require('http');
var fs=require('fs');  // fs kütüphanesi file system kodlarını aktarır.
http.createServer(function(req,res){
      fs.readFile('demofile1.html',function(err,data){
          res.writeHead(200,{'Content-type':'text/html'}); 
    // text/html gelen verinin html olarak algılanmasını sağlar.
      res.write(data);// data içinde yazdığımız html kodları vardır.
      res.end();// işlemin bittiğini gösteririz.
});
}).listen(8080);// yukarıdaki işlemleri localhost:8080  portuna aktarır.