// dosya silme işlemi 

const fs = require('fs');

fs.unlink('demo2.txt',(err)=>{
    if (err)
       throw err;
       
       console.log("dosya silindi");
});