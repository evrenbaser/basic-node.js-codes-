const events = require('events');
const eventEmitter = new events.EventEmitter();

eventEmitter.on('selamla',() =>{
    console.log("merhaba node");
});
eventEmitter.emit('selamla');

setTimeout(() => {eventEmitter.emit('selamla');
}, 2000);

eventEmitter.on('merhaba',(isim)=> {
    console.log(`merhaba ${isim}`);  
});
const isim ="toprak";
eventEmitter.emit('merhaba',isim);

eventEmitter.on('nasilsin', (object)=>{
    console.log(`merhaba ${object.name} ${object.surname} nasılsın?`)});

    eventEmitter.emit('nasilsin',{name:'doğa', surname:'şensoy'});

    eventEmitter.once('merhabade', () => {
        console.log('merhaba herkese')
    });
    eventEmitter.emit('merhabade');
    eventEmitter.emit('merhabade');
    eventEmitter.emit('merhabade');
    eventEmitter.emit('merhabade');