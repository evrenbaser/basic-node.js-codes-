const express = require('express');
const app = express();

app.get('/',(req,res)=>{
    res.send('merhaba express');
});
app.listen(3000,()=>{
    console.log("express server çalıştı");
});
// express server ı çalıştırmak için bunu kurmamız
// gerekiyor   npm install express terminale yazalım.

//npm init -y


// npm install express-generator -g
//  express .    y
// npm install 
// npm start

