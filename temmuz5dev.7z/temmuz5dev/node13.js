// nodemon nedir ? 
// dosya üzerinde herhangi bir değişiklik yaparken
// tekrardan dosyayı kaydedip düzenlememiz gerekir
// nodeman hazır hale getirir
//  npm install -g nodemon   
// basit bir http sunucusu oluşturmak. 
const http = require('http');
const server = http.createServer((request, response)=>{
    console.log("bir istekte bulunuldu222");
    response.writeHead(200,{'content-type':'text/html;charset=utf-8'});
    response.write("<b>merhaba</b><p>herkese</p>");
    response.end();
});
server.listen(3000);
// nodemon ile tekrar tekrar kill terminal yapmaya gerek yok.
// projeyi kaydederek sayfayı yenilemeniz yeterli... 
