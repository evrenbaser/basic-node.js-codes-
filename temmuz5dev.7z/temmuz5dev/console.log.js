console.log("selam nasılsın");
console.log("selam nasılsın",2,"iyiyim");
console.log("bu gün acayip bir rüya gördüm");
var verikutusu="node js öğreniyorum";
var veribavulu=225;
console.log(verikutusu);
console.log(veribavulu);
console.log(veribavulu,verikutusu);
var sayi1=25;
var sayi2=30;
console.log(sayi1+sayi2);
var veribalonu="evren başer",
    yas=29,
    burc="basak",
    dogumtarihi="21.09.1989";
console.log(veribalonu,yas,burc,dogumtarihi);
// buraya artık açıklama yorum bilgileri yazabilirim.
// consolelog ile ekrana veri yazdırma yaptı.
console.log(sayi1+sayi2+"sayılar"+"javascript");
console.log(sayi1*sayi2);
console.log(sayi1/sayi2);
console.log(sayi1++);// bir arttırdık.
console.log(sayi2--);// bir azalttık