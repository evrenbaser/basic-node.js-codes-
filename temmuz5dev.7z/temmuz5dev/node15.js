// GET       www.bunedio.com/register?username=evren       
// POST      www.bunedio.com/register?
// PUT           
// DELETE     
// basit bir yönlendirme işlemi yapalım arkadaşlar :)

const http = require('http');
const server = http.createServer((request, response)=>{
  
    response.writeHead(200,{'content-type':'text/html;charset=utf-8'});
            if(request.method === "GET"){
                    if(request.url === '/')
                    response.write("index sayfadasındasınız.");
                    else if (request.url ==='/iletisim')
                    response.write("iletişim sayfasındasınız.");
                    else 
                    response.write("bu sayfa bulunamadı");
            }
            response.end();
});
server.listen(3000); // localhost:3000

